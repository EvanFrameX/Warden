from setuptools import setup, find_packages

setup(
    name="Warden",  # Replace with your package name
    version='0.0.1',     # Package version
    packages=find_packages(),
    description="Warden makes it easier to use Pygame",
    author="EvanFrameX",
    author_email="<piescandale@gmail.com>",
)
